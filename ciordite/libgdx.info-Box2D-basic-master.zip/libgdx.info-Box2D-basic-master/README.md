# libgdx.info-Box2D-basic
LibGDX.info: Supporting code for basic Box2d / Scene2d: https://libgdx.info/box2d-basic/
